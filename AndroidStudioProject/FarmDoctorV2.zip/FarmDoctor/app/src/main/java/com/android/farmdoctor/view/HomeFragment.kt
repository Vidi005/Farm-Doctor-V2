package com.android.farmdoctor.view

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.navigation.fragment.NavHostFragment
import com.android.farmdoctor.R
import kotlinx.android.synthetic.main.fragment_home.*

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : Fragment(), View.OnClickListener {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        cv_search_plant_varieties.setOnClickListener(this)
        cv_detection_histories.setOnClickListener(this)
        cv_detection.setOnClickListener(this)
        cv_list_plant_diseases.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v) {
            cv_search_plant_varieties -> NavHostFragment
                .findNavController(this)
                .navigate(R.id.action_homeFragment_to_plantSpeciesFragment)
            cv_detection_histories -> NavHostFragment
                .findNavController(this)
                .navigate(R.id.action_homeFragment_to_detectionHistoriesFragment)
            cv_detection -> NavHostFragment
                .findNavController(this)
                .navigate(R.id.action_homeFragment_to_cameraFragment)
            cv_list_plant_diseases -> NavHostFragment
                .findNavController(this)
                .navigate(R.id.action_homeFragment_to_listDiseasesFragment)
        }
    }

    private fun setActionBar() {
        val drawable = ResourcesCompat.getDrawable(resources,
            R.drawable.fd_logo, null)
        val bitmap = drawable?.toBitmap()
        val scaledDrawable = BitmapDrawable(resources,
            bitmap?.let { Bitmap.createScaledBitmap(it, 60, 60, true) })
        (activity as AppCompatActivity?)?.supportActionBar?.setHomeAsUpIndicator(scaledDrawable)
        (activity as AppCompatActivity?)?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        (activity as AppCompatActivity?)?.supportActionBar?.title = "Farm Doctor"
    }
}
