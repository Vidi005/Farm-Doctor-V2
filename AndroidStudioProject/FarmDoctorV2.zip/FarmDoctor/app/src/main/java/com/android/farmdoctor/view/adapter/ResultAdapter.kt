package com.android.farmdoctor.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.farmdoctor.R
import com.android.farmdoctor.model.Detection
import kotlinx.android.synthetic.main.item_plant_disease.view.*
import kotlin.collections.ArrayList

class ResultAdapter(private val resultDetection: ArrayList<Detection>) : RecyclerView.Adapter<ResultAdapter.RecyclerViewHolder>() {

    private lateinit var onItemClickDetail: OnItemClickCallBack

    fun setOnItemClickCallback(onItemClickCallBack: OnItemClickCallBack) {
        this.onItemClickDetail = onItemClickCallBack
    }

    fun setResultDetectionData(items: ArrayList<Detection>) {
        resultDetection.clear()
        items.sortByDescending { it.accuracy }
        resultDetection.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
        val view: View = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_plant_disease, parent, false)
        return RecyclerViewHolder(view)
    }

    override fun getItemCount(): Int {
        val limit = 1
        return if (resultDetection.size > limit) limit
        else resultDetection.size
    }

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) =
        holder.bind(resultDetection[position])

    inner class RecyclerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(detection: Detection) {
            with(itemView) {
                tv_name_result.text = "Name of Disease: ${detection.name}"
                //val acc = "Probability: ${detection.accuracy*100}%"
                tv_acc_result.text = "Probability: ${detection.accuracy}%"
                itemView.setOnClickListener { onItemClickDetail.onItemClicked(detection) }
            }
        }
    }

    interface OnItemClickCallBack {
        fun onItemClicked(data: Detection)
    }
}