package com.android.farmdoctor.viewmodel

import android.content.Context
import android.content.res.Resources
import android.os.AsyncTask
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.model.factory.Classification
import com.android.farmdoctor.model.Detection
import com.priyankvasa.android.cameraviewex.Image
import kotlinx.coroutines.*

class CameraViewModel : ViewModel() {

    companion object {
        private val TAG = CameraViewModel::class.java.simpleName
    }
    private lateinit var classifier: Classification
    //private var job: Job? = null
    private var detectionTask: AsyncTask<*, *, *>? = null
    private val listDetectionPicture = MutableLiveData<ArrayList<Detection>>()
    private val listDetectionPreviewFrames = MutableLiveData<ArrayList<Detection>>()

    fun setDetectionPicture(image: Image, context: Context, resources: Resources) {
        classifier = Classification(
            context.assets,
            resources
        )
        /*GlobalScope.launch(Dispatchers.Main) {
            try {
                val differedRecognitions = async(Dispatchers.IO) {
                    classifier.recognizeTakenPicture(image.data, resources)
                }
                val recognitions = differedRecognitions.await()
                Log.d(TAG, "$recognitions")
                listDetection.postValue(recognitions)
                Log.d(TAG, "$listDetection")
            } catch (e: Exception) {
                Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
            }
        }*/
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val recognitions = classifier.recognizeTakenPicture(image.data, resources)
                Log.d(TAG, "$recognitions")
                withContext(Dispatchers.Main) {
                    listDetectionPicture.postValue(recognitions)
                    Log.d(TAG, "$listDetectionPicture")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun setDetectionPreviewFrames(image: Image, context: Context, resources: Resources) {
        classifier = Classification(
            context.assets,
            resources
        )
        if (detectionTask != null && detectionTask?.status == AsyncTask.Status.RUNNING) {
            detectionTask?.cancel(true)
            detectionTask = null
        }
        detectionTask = object : AsyncTask<Void, Void, Void>() {
            override fun doInBackground(vararg params: Void?): Void? {
                val recognitions = classifier.recognizePreviewFrames(image, resources)
                listDetectionPreviewFrames.postValue(recognitions)
                return null
            }
        }.execute()
        /*GlobalScope.launch(Dispatchers.IO) {
            try {
                val recognitions = classifier.recognizePreviewFrames(image, resources)
                listDetectionPreviewFrame.postValue(recognitions)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
                }
            }
        }*/
        //job = Job()
        /*if (job?.isActive == true || job != null) {
            job?.cancel()
            job = null
        } else if (job?.isCompleted == true || job == null) {
            job?.start()
        }
        job = GlobalScope.launch(Dispatchers.IO) {
            try {
                val recognitions = classifier.recognizePreviewFrames(image, resources)
                listDetectionPreviewFrame.postValue(recognitions)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
                }
                //Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
            }
        }*/
        //job?.start()
    }

    fun getDetectionPicture(): LiveData<ArrayList<Detection>> = listDetectionPicture

    fun getDetectionPreviewFrames(): LiveData<ArrayList<Detection>> = listDetectionPreviewFrames
}