package com.android.farmdoctor.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.farmdoctor.R
import com.android.farmdoctor.database.DetectionHistoryHelper

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val detectionHistoryHelper = DetectionHistoryHelper.getInstance(applicationContext)
        if (detectionHistoryHelper.open().equals(true)) detectionHistoryHelper.close()
    }
}
