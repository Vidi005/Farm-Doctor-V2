package com.android.farmdoctor.model.factory

import android.content.res.AssetManager
import android.content.res.Resources
import android.content.res.TypedArray
import android.graphics.*
import com.android.farmdoctor.R
import com.android.farmdoctor.model.Detection
import com.priyankvasa.android.cameraviewex.Image
import org.tensorflow.lite.Interpreter
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class Classification(assetManager: AssetManager, resources: Resources) {

    companion object {
        private val TAG = Classification::class.java.simpleName
        private const val MODEL_PATH = "Plant_Leaf_Diseases_Classification_MobileNet.tflite"
        private const val BATCH_SIZE = 1
        private const val MODEL_INPUT_SIZE = 224
        private const val BYTES_PER_CHANNEL = 4
        private const val CHANNEL_SIZE = 3
        private const val IMAGE_STD = 255f
    }

    private lateinit var dataPicture: TypedArray
    private lateinit var dataDetail: TypedArray
    private val tfLiteModel = Interpreter(getModelByteBuffer(assetManager,
        MODEL_PATH
    ))
    private val dataName = resources.getStringArray(R.array.name)

    private fun getModelByteBuffer(
        assetManager: AssetManager,
        modelPath: String
    ): MappedByteBuffer {
        val fileDescriptor = assetManager.openFd(modelPath)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    private fun prepare(resources: Resources) {
        dataPicture = resources.obtainTypedArray(R.array.leaves_picture)
        dataDetail = resources.obtainTypedArray(R.array.detail_layout)
    }

    fun recognizeTakenPicture(data: ByteArray, resources: Resources): ArrayList<Detection> {
        val unscaledBitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
        val bitmap = Bitmap.createScaledBitmap(
            unscaledBitmap,
            MODEL_INPUT_SIZE,
            MODEL_INPUT_SIZE,
            false)
        val byteBuffer = convertBitmapToByteBuffer(bitmap)
        val result = Array(BATCH_SIZE) { FloatArray(dataName.size) }
        tfLiteModel.run(byteBuffer, result)
        return parseResults(result, resources)
    }

    fun recognizePreviewFrames(image: Image, resources: Resources): ArrayList<Detection> {
        val data: ByteArray
        val yuvImage = YuvImage(
            image.data,
            ImageFormat.NV21,
            image.width,
            image.height,
            null
        )
        val jpegDataStream = ByteArrayOutputStream()
        val previewFrameScale = 0.4f
        yuvImage.compressToJpeg(
            Rect(0, 0, image.width, image.height),
            (100 * previewFrameScale).toInt(),
            jpegDataStream
        )
        data = jpegDataStream.toByteArray()
        val options = BitmapFactory.Options()
        options.inPreferredConfig = Bitmap.Config.ARGB_8888
        val unscaledBitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
        val bitmap = Bitmap.createScaledBitmap(
            unscaledBitmap,
            MODEL_INPUT_SIZE,
            MODEL_INPUT_SIZE,
            false)
        val byteBuffer = convertBitmapToByteBuffer(bitmap)
        val result = Array(BATCH_SIZE) { FloatArray(dataName.size) }
        tfLiteModel.run(byteBuffer, result)
        return parseResults(result, resources)
    }

    fun recognizeImage(bitmap: Bitmap?, resources: Resources): ArrayList<Detection> {
        val bitmapData =
            bitmap?.let { Bitmap.createScaledBitmap(
                it,
                MODEL_INPUT_SIZE,
                MODEL_INPUT_SIZE,
                false) }
        val byteBuffer = convertBitmapToByteBuffer(bitmapData)
        val result = Array(BATCH_SIZE) { FloatArray(dataName.size) }
        tfLiteModel.run(byteBuffer, result)
        return parseResults(result, resources)
    }

    private fun convertBitmapToByteBuffer(bitmap: Bitmap?): ByteBuffer {
        val byteBuffer = ByteBuffer.allocateDirect(
            BATCH_SIZE *
                    MODEL_INPUT_SIZE *
                    MODEL_INPUT_SIZE *
                    BYTES_PER_CHANNEL *
                    CHANNEL_SIZE
        )
            .apply { order(ByteOrder.nativeOrder()) }
        val pixelValues = IntArray(MODEL_INPUT_SIZE * MODEL_INPUT_SIZE)
        bitmap?.getPixels(pixelValues, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        var pixel = 0
        for (i in 0 until MODEL_INPUT_SIZE) {
            for (j in 0 until MODEL_INPUT_SIZE) {
                val pixelValue = pixelValues[pixel++]
                byteBuffer.putFloat((pixelValue shr 16 and 0xFF) / IMAGE_STD)
                byteBuffer.putFloat((pixelValue shr 8 and 0xFF) / IMAGE_STD)
                byteBuffer.putFloat((pixelValue and 0xFF) / IMAGE_STD)
            }
        }
        return byteBuffer
    }

    private fun parseResults(result: Array<FloatArray>, resources: Resources): ArrayList<Detection> {
        prepare(resources)
        val recognitions = ArrayList<Detection>()
        val accuracy = result[0]
        for (position in dataName.indices) {
            val detection = Detection(
                dataName[position],
                accuracy[position] * 100,
                dataPicture.getResourceId(position, -1),
                dataDetail.getResourceId(position, -1)
            )
            recognitions.add(detection)
        }
        dataPicture.recycle()
        dataDetail.recycle()
        return recognitions
    }
}