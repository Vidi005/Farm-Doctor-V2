package com.android.farmdoctor.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PlantSpecies(
    val image: String?,
    val scientificName: String?,
    val commonName: String?,
    val author: String?,
    val rank: String?
) : Parcelable