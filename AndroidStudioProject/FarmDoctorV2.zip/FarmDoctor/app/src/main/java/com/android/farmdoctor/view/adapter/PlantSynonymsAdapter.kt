package com.android.farmdoctor.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.farmdoctor.R
import com.android.farmdoctor.model.Synonym
import kotlinx.android.synthetic.main.item_list_synonyms.view.*

class PlantSynonymsAdapter(private val listSynonyms: ArrayList<Synonym>) :
    RecyclerView.Adapter<PlantSynonymsAdapter.RecyclerViewHolder>() {

    fun setPlantSynonymData(items: ArrayList<Synonym>) {
        listSynonyms.clear()
        listSynonyms.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_list_synonyms, parent, false)
        return RecyclerViewHolder(view)
    }

    override fun getItemCount(): Int = listSynonyms.size

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) =
        holder.bind(listSynonyms[position])

    inner class RecyclerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        @SuppressLint("SetTextI18n")
        fun bind(listSynonym: Synonym) {
            with(itemView) {
                tv_no_scientific_name_synonym.text = "${listSynonym.number}."
                tv_item_scientific_name_synonym.text = listSynonym.synonym ?: "-"
            }
        }
    }
}