package com.android.farmdoctor.viewmodel

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.database.DetectionHistoryHelper
import com.android.farmdoctor.model.entity.DetectionHistory
import com.android.farmdoctor.helper.MappingHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class DetectionHistoriesViewModel : ViewModel() {

    private lateinit var detectionHistoryHelper: DetectionHistoryHelper
    private val listDetectionHistories = MutableLiveData<ArrayList<DetectionHistory>>()

    fun setDetectionHistory(context: Context) {
        detectionHistoryHelper = DetectionHistoryHelper.getInstance(context)
        detectionHistoryHelper.open()
        GlobalScope.launch(Dispatchers.Main) {
            try {
                val deferredDetectionHistories = async(Dispatchers.IO) {
                    val cursor = detectionHistoryHelper.queryAll()
                    MappingHelper.mapCursorToArrayList(cursor)
                }
                val detectionHistories = deferredDetectionHistories.await()
                listDetectionHistories.postValue(detectionHistories)
            } catch (e: Exception) {
                Toast.makeText(context, e.message.toString(), Toast.LENGTH_LONG).show()
            }
        }
    }

    fun getDetectionHistory(): LiveData<ArrayList<DetectionHistory>> = listDetectionHistories
}