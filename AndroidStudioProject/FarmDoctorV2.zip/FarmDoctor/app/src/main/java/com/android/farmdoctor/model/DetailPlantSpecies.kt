package com.android.farmdoctor.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DetailPlantSpecies(
    val image: String?,
    val author: String?,
    val rank: String?,
    val year: String?,
    val status: String?,
    val genus: String,
    val family: String?,
    val synonyms: ArrayList<Synonym>?
) : Parcelable