package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.farmdoctor.R
import com.android.farmdoctor.model.PlantSpecies
import com.android.farmdoctor.view.DetailPlantSpeciesFragment.Companion.EXTRA_COMMON_NAME
import com.android.farmdoctor.view.DetailPlantSpeciesFragment.Companion.EXTRA_SCIENTIFIC_NAME
import com.android.farmdoctor.view.adapter.PlantSpeciesAdapter
import com.android.farmdoctor.viewmodel.PlantSpeciesViewModel
import kotlinx.android.synthetic.main.fragment_plant_species.*

/**
 * A simple [Fragment] subclass.
 */
class PlantSpeciesFragment : Fragment() {

    private lateinit var plantSpeciesAdapter: PlantSpeciesAdapter
    private lateinit var plantSpeciesViewModel: PlantSpeciesViewModel
    private val list = ArrayList<PlantSpecies>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_plant_species, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        showRecyclerView()
        getViewModelLiveData()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) {
            activity?.onBackPressed()
            closeKeyboard()
        }
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Plant Species"
        }
    }

    private fun showRecyclerView() {
        rv_list_plant_species.layoutManager = LinearLayoutManager(activity)
        plantSpeciesAdapter = PlantSpeciesAdapter(list)
        rv_list_plant_species.adapter = plantSpeciesAdapter
        plantSpeciesAdapter.notifyDataSetChanged()
        rv_list_plant_species.setHasFixedSize(true)
        plantSpeciesAdapter.setOnItemClickCallback(object : PlantSpeciesAdapter.OnItemClickCallBack {
            override fun onItemClicked(data: PlantSpecies) = setSelectedPlantSpecies(data)
        })
    }

    private fun setSelectedPlantSpecies(data: PlantSpecies) {
        val mBundle = Bundle().apply {
            putString(EXTRA_SCIENTIFIC_NAME, data.scientificName)
            putString(EXTRA_COMMON_NAME, data.commonName)
        }
        NavHostFragment
            .findNavController(this)
            .navigate(R.id.action_plantSpeciesFragment_to_detailPlantSpeciesFragment, mBundle)
        closeKeyboard()
    }

    private fun getViewModelLiveData() {
        plantSpeciesViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(PlantSpeciesViewModel::class.java)
        searchPlantSpecies()
        plantSpeciesViewModel.getSearchSpecies().observe(viewLifecycleOwner, Observer {
            if (it != null) {
                showPlantSpeciesItems(it)
                showLoading(false)
            }
        })
    }

    @SuppressLint("SetTextI18n")
    private fun showPlantSpeciesItems(plantSpeciesItems: ArrayList<PlantSpecies>?) {
        plantSpeciesItems?.let { plantSpeciesAdapter.setPlantSpeciesData(it) }
        when {
            plantSpeciesItems?.size as Int >= 1 -> {
                tv_search_result.text = "Items Found: ${plantSpeciesItems.size}"
                showEmptySearchResult(false)
            }
            plantSpeciesItems.size == 0 -> {
                list.clear()
                tv_search_result.text = "Search Result not Found"
                showEmptySearchResult(true)
            }
        }
    }

    private fun searchPlantSpecies() {
        sv_plant_species.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText?.isNotEmpty() == true) {
                    plantSpeciesViewModel.setSearchSpecies(newText, requireContext())
                    showLoading(true)
                    tv_search_result.text = "Searching..."
                } else {
                    showLoading(false)
                    list.clear()
                    tv_search_result.text = "Click and Type to Search"
                }
                showEmptySearchResult(false)
                return true
            }
        })
    }

    private fun showLoading(state: Boolean) {
        if (state) pb_search_species.visibility = View.VISIBLE
        else pb_search_species.visibility = View.GONE
    }

    private fun showEmptySearchResult(state: Boolean) {
        if (state) iv_search_not_found.visibility = View.VISIBLE
        else iv_search_not_found.visibility = View.GONE
    }

    private fun closeKeyboard() {
        val view: View? = activity?.currentFocus
        if (view != null) {
            val mInputMethodManager: InputMethodManager =
                activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            mInputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
        }
    }
}
