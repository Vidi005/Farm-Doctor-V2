package com.android.farmdoctor.model.factory

import android.content.res.Resources
import android.content.res.TypedArray
import com.android.farmdoctor.R
import com.android.farmdoctor.model.PlantDisease

object ListDiseases {

    var plantDiseases = ArrayList<PlantDisease>()
    private lateinit var dataPicture: TypedArray
    private lateinit var dataName: Array<String>
    private lateinit var dataDetail: TypedArray

    fun addItem(resources: Resources): ArrayList<PlantDisease> {
        prepare(resources)
        for (position in dataName.indices) {
            val plantDisease = PlantDisease(
                dataPicture.getResourceId(position, -1),
                dataName[position],
                dataDetail.getResourceId(position, -1)
            )
            plantDiseases.add(plantDisease)
        }
        return plantDiseases
    }

    private fun prepare(resources: Resources) {
        dataPicture = resources.obtainTypedArray(R.array.leaves_picture)
        dataName = resources.getStringArray(R.array.name)
        dataDetail = resources.obtainTypedArray(R.array.detail_layout)
    }
}