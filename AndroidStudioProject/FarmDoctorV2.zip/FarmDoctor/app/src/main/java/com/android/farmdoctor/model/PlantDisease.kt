package com.android.farmdoctor.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PlantDisease(
    val picture: Int?,
    val name: String?,
    val detail: Int?
) : Parcelable