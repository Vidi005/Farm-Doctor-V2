package com.android.farmdoctor.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.GridLayoutManager
import com.android.farmdoctor.R
import com.android.farmdoctor.model.factory.ListDiseases.addItem
import com.android.farmdoctor.model.factory.ListDiseases.plantDiseases
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_DETAIL
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_NAME
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_PICTURE
import com.android.farmdoctor.view.adapter.PlantDiseasesAdapter
import com.android.farmdoctor.model.PlantDisease
import kotlinx.android.synthetic.main.fragment_list_diseases.*

/**
 * A simple [Fragment] subclass.
 */
class ListDiseasesFragment : Fragment() {

    private var plantDiseasesAdapter =
        PlantDiseasesAdapter(plantDiseases)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list_diseases, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addItem(resources)
        showRecyclerView()
    }

    private fun showRecyclerView() {
        rv_list_diseases.layoutManager = GridLayoutManager(activity, 2)
        plantDiseasesAdapter =
            PlantDiseasesAdapter(plantDiseases)
        rv_list_diseases.adapter = plantDiseasesAdapter
        plantDiseasesAdapter.notifyDataSetChanged()
        rv_list_diseases.setHasFixedSize(true)
        plantDiseasesAdapter.setOnItemClickCallback(object :
            PlantDiseasesAdapter.OnItemClickCallBack {
            override fun onItemClicked(data: PlantDisease) = setSelectedPlantDisease(data)
        })
    }

    private fun setSelectedPlantDisease(data: PlantDisease) {
        val mBundle = Bundle().apply {
            putString(EXTRA_NAME, data.name)
            data.picture?.let { putInt(EXTRA_PICTURE, it) }
            data.detail?.let { putInt(EXTRA_DETAIL, it) }
        }
        NavHostFragment.findNavController(this).navigate(R.id.action_listDiseasesFragment_to_listDiseasesDetailFragment, mBundle)
    }
}
