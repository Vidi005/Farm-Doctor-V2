package com.android.farmdoctor.view

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.farmdoctor.viewmodel.CameraViewModel
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_DETAIL
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_NAME
import com.android.farmdoctor.view.ListDiseasesDetailFragment.Companion.EXTRA_PICTURE
import com.android.farmdoctor.R
import com.android.farmdoctor.view.adapter.ResultAdapter
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_ACCURACY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DATE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_IMAGE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_NAME
import com.android.farmdoctor.database.DetectionHistoryHelper
import com.android.farmdoctor.model.Detection
import com.priyankvasa.android.cameraviewex.Modes
import kotlinx.android.synthetic.main.fragment_camera.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class CameraFragment : Fragment(), View.OnClickListener {

    companion object {
        private const val REQUEST_CAMERA_CODE = 100
        private const val PREFS_AUTO_DETECT = "auto_detect_pref"
        private const val PREFS_FLASHLIGHT_MODE = "flashlight_mode_pref"
        private const val PREFS_DETECTION_HISTORY = "detection_history_pref"
    }

    private lateinit var resultAdapter: ResultAdapter
    private lateinit var cameraViewModel: CameraViewModel
    private lateinit var preferences: SharedPreferences
    private lateinit var detectionHistoryHelper: DetectionHistoryHelper
    private var dataImage: ByteArray? = null
    private val list = ArrayList<Detection>()
    private var flashModes: Int = 1
    private var isButtonClicked = false
    private var canUseCamera = true
    private var isDetectionHistoryEnabled = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_camera, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setCamera()
        showRecyclerView()
    }

    private fun setCamera() {
        if (!canUseCamera()) {
            requestCameraPermissions()
        } else {
            btn_detect.setOnClickListener(this)
            iv_flash_light_mode.setOnClickListener(this)
            cb_enable_history.setOnClickListener(this)
            setFlashModes()
            setDetectionMode()
            loadDetectionMode()
            enableDetectionHistory()
            getViewModelLiveData()
        }
    }

    private fun getViewModelLiveData() {
        preferences = activity?.getSharedPreferences(PREFS_AUTO_DETECT, Context.MODE_PRIVATE) as SharedPreferences
        sw_detection_mode.isChecked = preferences.getBoolean(PREFS_AUTO_DETECT, false)
        if (sw_detection_mode.isChecked) {
            cameraViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
                .get(CameraViewModel::class.java)
            detectPreviewFrames(requireContext(), resources)
            cameraViewModel.getDetectionPreviewFrames().observe(viewLifecycleOwner, Observer {
                if (it != null) {
                    showDetectionItems(it)
                }
            })
        } else {
            detectionHistoryHelper = DetectionHistoryHelper.getInstance(requireContext())
            detectionHistoryHelper.open()
            cameraViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
                .get(CameraViewModel::class.java)
            detectPicture(requireContext(), resources)
            cameraViewModel.getDetectionPicture().observe(viewLifecycleOwner, Observer {
                if (it != null) {
                    showDetectionItems(it)
                    Toast.makeText(context, "Success!", Toast.LENGTH_SHORT).show()
                    stateLoadingProgress(false)
                    isButtonClicked = false
                    val detectionItems = it
                    detectionItems.sortByDescending { detection -> detection.accuracy }
                    val checkAcc = detectionHistoryHelper.checkAccuracy(detectionItems[0].accuracy.toString())
                    //val checkName = detectionHistoryHelper.checkName(detectionItems[0].name.toString())
                    if (isDetectionHistoryEnabled && !checkAcc) addDetectionHistory()
                }
            })
        }
    }

    private fun loadDetectionMode() {
        preferences = activity?.getSharedPreferences(PREFS_AUTO_DETECT, Context.MODE_PRIVATE) as SharedPreferences
        sw_detection_mode.isChecked = preferences.getBoolean(PREFS_AUTO_DETECT, false)
        if (sw_detection_mode.isChecked) {
            camera.disableCameraMode(Modes.CameraMode.SINGLE_CAPTURE)
            camera.setCameraMode(Modes.CameraMode.CONTINUOUS_FRAME)
            btn_detect.visibility = View.GONE
            group_enable_history.visibility = View.GONE
            tv_enable_history.visibility = View.GONE
            cb_enable_history.visibility = View.GONE
        } else {
            camera.disableCameraMode(Modes.CameraMode.CONTINUOUS_FRAME)
            camera.setCameraMode(Modes.CameraMode.SINGLE_CAPTURE)
            btn_detect.visibility = View.VISIBLE
            group_enable_history.visibility = View.VISIBLE
            tv_enable_history.visibility = View.VISIBLE
            cb_enable_history.visibility = View.VISIBLE
        }
    }

    private fun setDetectionMode() {
        preferences = activity?.getSharedPreferences(PREFS_AUTO_DETECT, Context.MODE_PRIVATE) as SharedPreferences
        sw_detection_mode.apply {
            isChecked = preferences.getBoolean(PREFS_AUTO_DETECT, false)
            setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    preferences.edit { putBoolean(PREFS_AUTO_DETECT, true) }
                } else {
                    preferences.edit { clear() }
                }
                loadDetectionMode()
                getViewModelLiveData()
            }
        }
    }

    private fun requestCameraPermissions() {
        activity?.let { ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.CAMERA),
            REQUEST_CAMERA_CODE
        ) }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (REQUEST_CAMERA_CODE == requestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                detectPicture(requireContext(), resources)
                detectPreviewFrames(requireContext(), resources)
            } else {
                Toast.makeText(activity, "Can't Use Camera", Toast.LENGTH_LONG).show()
                requestCameraPermissions()
            }
        }
    }

    private fun canUseCamera() =
        activity?.let {
            ContextCompat.checkSelfPermission(
                it,
                Manifest.permission.CAMERA
            )
        } == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    override fun onResume() {
        try {
            super.onResume()
            if (canUseCamera()) {
                camera.start()
            }
        } catch (e: IOException) {
            canUseCamera = false
            Toast.makeText(activity, "Camera can't be accessed", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            canUseCamera = false
            Toast.makeText(activity, "Camera can't be accessed", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        if (canUseCamera()) {
            camera.stop()
            if (isButtonClicked) {
                isButtonClicked = false
                stateLoadingProgress(false)
            }
        }
        super.onPause()
    }

    @SuppressLint("MissingPermission")
    private fun setFlashModes() {
        preferences = activity?.getSharedPreferences(PREFS_FLASHLIGHT_MODE, Context.MODE_PRIVATE) as SharedPreferences
        flashModes = preferences.getInt(PREFS_FLASHLIGHT_MODE, 1)
        when (flashModes) {
            1 -> {
                iv_flash_light_mode.setImageResource(R.drawable.ic_flash_auto)
                camera.flash = Modes.Flash.FLASH_AUTO
            }
            2 -> {
                iv_flash_light_mode.setImageResource(R.drawable.ic_flash_on)
                camera.flash = Modes.Flash.FLASH_ON
            }
            3 -> {
                iv_flash_light_mode.setImageResource(R.drawable.ic_flash_off)
                camera.flash = Modes.Flash.FLASH_OFF
            }
            4 -> {
                iv_flash_light_mode.setImageResource(R.drawable.ic_flash_torch)
                camera.flash = Modes.Flash.FLASH_TORCH
                flashModes = 0
            }
        }
    }

    private fun enableDetectionHistory() {
        if (!sw_detection_mode.isChecked) {
            preferences = activity?.getSharedPreferences(PREFS_DETECTION_HISTORY, Context.MODE_PRIVATE) as SharedPreferences
            cb_enable_history.isChecked = preferences.getBoolean(PREFS_DETECTION_HISTORY, false)
            isDetectionHistoryEnabled = cb_enable_history.isChecked
        }
    }

    private fun showRecyclerView() {
        rv_detection_result.layoutManager = LinearLayoutManager(activity)
        resultAdapter = ResultAdapter(list)
        rv_detection_result.adapter = resultAdapter
        resultAdapter.notifyDataSetChanged()
        rv_detection_result.setHasFixedSize(true)
        resultAdapter.setOnItemClickCallback(object : ResultAdapter.OnItemClickCallBack {
            override fun onItemClicked(data: Detection) {
                setSelectedPlantDisease(data)
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun detectPicture(context: Context, resources: Resources) {
        camera.addPictureTakenListener {
            stateLoadingProgress(true)
            cameraViewModel.setDetectionPicture(it, context, resources)
            dataImage = it.data
            //val bitmap = BitmapFactory.decodeByteArray(dataImage, 0, dataImage.size)
        }
    }

    @SuppressLint("MissingPermission")
    private fun detectPreviewFrames(context: Context, resources: Resources) {
        camera.setContinuousFrameListener(10f) {
            cameraViewModel.setDetectionPreviewFrames(it, context, resources)
        }
    }

    private fun showDetectionItems(detectionItems: ArrayList<Detection>) {
        resultAdapter.setResultDetectionData(detectionItems)
    }

    private fun setSelectedPlantDisease(data: Detection) {
        val mBundle = Bundle().apply {
            putString(EXTRA_NAME, data.name)
            data.picture?.let { putInt(EXTRA_PICTURE, it) }
            data.detail?.let { putInt(EXTRA_DETAIL, it) }
        }
        NavHostFragment.findNavController(this).navigate(R.id.action_cameraFragment_to_listDiseasesDetailFragment, mBundle)
    }

    private fun addDetectionHistory() {
        val items = cameraViewModel.getDetectionPicture().value
        items?.sortByDescending { it.accuracy }
        val values = ContentValues().apply {
            put(COLUMN_IMAGE, dataImage)
            put(COLUMN_NAME, items?.get(0)?.name)
            put(COLUMN_ACCURACY, items?.get(0)?.accuracy.toString())
            put(COLUMN_DATE, getCurrentDate())
        }
        detectionHistoryHelper = DetectionHistoryHelper.getInstance(requireContext())
        detectionHistoryHelper.insert(values)
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault())
        val date = Date()
        return dateFormat.format(date)
    }

    private fun stateLoadingProgress(state: Boolean) {
        if (state) {
            group_progress.visibility = View.VISIBLE
            pb_process.visibility = View.VISIBLE
            tv_process.visibility = View.VISIBLE
        } else {
            group_progress.visibility = View.GONE
            pb_process.visibility = View.GONE
            tv_process.visibility = View.GONE
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            btn_detect -> if (!isButtonClicked && canUseCamera) {
                isButtonClicked = true
                camera.capture()
            } else if (isButtonClicked) {
                isButtonClicked = false
                stateLoadingProgress(false)
            }
            iv_flash_light_mode -> {
                flashModes++
                preferences.edit { putInt(PREFS_FLASHLIGHT_MODE, flashModes) }
                setFlashModes()
            }
            cb_enable_history -> {
                if (cb_enable_history.isChecked) {
                    isDetectionHistoryEnabled = true
                    preferences.edit { putBoolean(PREFS_DETECTION_HISTORY, true) }
                }
                else {
                    isDetectionHistoryEnabled = false
                    preferences.edit { clear() }
                }
                enableDetectionHistory()
            }
        }
    }
}
