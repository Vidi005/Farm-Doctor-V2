package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.android.farmdoctor.R
import com.android.farmdoctor.model.entity.DetectionHistory
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_detection_history.*

/**
 * A simple [Fragment] subclass.
 */
class DetailDetectionHistoryFragment : Fragment() {

    companion object {
        const val EXTRA_DETECTION_HISTORY = "extra_detection_history"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_detection_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getSelectedDetectionHistory()
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedDetectionHistory() {
        if (arguments != null) {
            val detectionHistory =
                arguments?.getParcelable<DetectionHistory>(EXTRA_DETECTION_HISTORY) as DetectionHistory
            val dataImage = detectionHistory.image
            val dataName = detectionHistory.name
            val dataAcc = detectionHistory.accuracy
            val dataDate = detectionHistory.date
            Glide.with(this).load(dataImage).into(iv_history_image_received)
            tv_history_name_received.text = "Name: $dataName"
            tv_history_acc_received.text = "Probability: $dataAcc%"
            tv_history_date_received.text = dataDate
        }
    }
}
