package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.android.farmdoctor.R
import com.android.farmdoctor.database.DetectionHistoryHelper
import com.android.farmdoctor.model.entity.DetectionHistory
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_detection_history.*

/**
 * A simple [Fragment] subclass.
 */
class DetailDetectionHistoryFragment : Fragment() {

    companion object {
        const val EXTRA_DETECTION_HISTORY = "extra_detection_history"
    }
    private lateinit var detectionHistoryHelper: DetectionHistoryHelper
    private var detectionHistory: DetectionHistory? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_detection_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        getSelectedDetectionHistory()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_delete, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        showAlertDialog(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedDetectionHistory() {
        if (arguments != null) {
            detectionHistory =
                arguments?.getParcelable<DetectionHistory>(EXTRA_DETECTION_HISTORY) as DetectionHistory
            val dataImage = detectionHistory?.image
            val dataName = detectionHistory?.name
            val dataAcc = detectionHistory?.accuracy
            val dataDate = detectionHistory?.date
            Glide.with(this).load(dataImage).into(iv_history_image_received)
            tv_history_name_received.text = "Name: $dataName"
            tv_history_acc_received.text = "Probability: $dataAcc%"
            tv_history_date_received.text = dataDate
        }
    }

    private fun showAlertDialog(showAlertDialog: Int) {
        if (showAlertDialog == R.id.app_bar_delete) {
            val dialogTitle = "Delete History"
            val dialogMessage = "Are you sure want to delete this history?"
            val alertDialogBuilder = AlertDialog.Builder(requireContext())
            alertDialogBuilder.setTitle(dialogTitle)
            alertDialogBuilder
                .setMessage(dialogMessage)
                .setPositiveButton("Yes") { _, _ -> deleteDetectionHistory() }
                .setNegativeButton("No") { dialog, _ -> dialog.cancel() }
            val alertDialog = alertDialogBuilder.create()
            alertDialog.show()
        }
    }

    private fun deleteDetectionHistory() {
        detectionHistoryHelper = DetectionHistoryHelper.getInstance(requireContext())
        detectionHistoryHelper.open()
        val result = detectionHistoryHelper.deleteById(detectionHistory?.id.toString()).toLong()
        if (result > 0) {
            activity?.onBackPressed()
            Toast.makeText(activity, "History successfully deleted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(activity, "Failed to delete the history!", Toast.LENGTH_LONG).show()
        }
    }
}
