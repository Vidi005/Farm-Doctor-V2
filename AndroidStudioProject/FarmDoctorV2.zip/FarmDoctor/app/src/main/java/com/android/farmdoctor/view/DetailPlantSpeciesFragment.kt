package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.android.farmdoctor.R
import com.android.farmdoctor.model.DetailPlantSpecies
import com.android.farmdoctor.viewmodel.DetailPlantSpeciesViewModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_plant_species.*

/**
 * A simple [Fragment] subclass.
 */
class DetailPlantSpeciesFragment : Fragment() {

    private lateinit var detailPlantSpeciesViewModel: DetailPlantSpeciesViewModel
    private lateinit var scientificName: String
    private lateinit var commonName: String
    companion object {
        const val EXTRA_SCIENTIFIC_NAME = "extra_scientific_name"
        const val EXTRA_COMMON_NAME = "extra_common_name"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_plant_species, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        getSelectedPlantSpecies()
        showLoading(true)
        getViewModelLiveData()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) activity?.onBackPressed()
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Plant Species"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedPlantSpecies() {
        if (arguments != null) {
            scientificName = arguments?.getString(EXTRA_SCIENTIFIC_NAME) ?: "-"
            commonName = arguments?.getString(EXTRA_COMMON_NAME) ?: "-"
            tv_scientific_name_received.text = scientificName
            tv_common_name_received.text = "($commonName)"
        }
    }

    private fun getViewModelLiveData() {
        detailPlantSpeciesViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(DetailPlantSpeciesViewModel::class.java)
        detailPlantSpeciesViewModel.apply {
           setDetailPlantSpecies(scientificName, requireContext())
            getDetailPlantSpecies().observe(viewLifecycleOwner, Observer {
                if (it != null) {
                    showDetailPlantSpecies(it)
                    showLoading(false)
                }
            })
        }
    }

    private fun showDetailPlantSpecies(detailPlantSpecies: DetailPlantSpecies?) {
        if (detailPlantSpecies?.image.isNullOrBlank() || detailPlantSpecies?.image == "null")
            Glide.with(this).load(R.drawable.ic_no_image).into(riv_image_received)
        else Glide.with(this).load(detailPlantSpecies?.image).into(riv_image_received)
        if (detailPlantSpecies?.author.isNullOrEmpty() || detailPlantSpecies?.author == "null")
            tv_author_received.text = "-"
        else tv_author_received.text = detailPlantSpecies?.author ?: "-"
        if (detailPlantSpecies?.rank.isNullOrEmpty() || detailPlantSpecies?.rank == "null")
            tv_rank_received.text = "-"
        else tv_rank_received.text = detailPlantSpecies?.rank ?: "-"
        if (detailPlantSpecies?.year.isNullOrEmpty() || detailPlantSpecies?.year == "null")
            tv_year_received.text = "-"
        else tv_year_received.text = detailPlantSpecies?.year ?: "-"
        if (detailPlantSpecies?.status.isNullOrEmpty() || detailPlantSpecies?.status == "null")
            tv_status_received.text = "-"
        else tv_status_received.text = detailPlantSpecies?.status ?: "-"
        if (detailPlantSpecies?.genus.isNullOrEmpty() || detailPlantSpecies?.genus == "null")
            tv_genus_received.text = "-"
        else tv_genus_received.text = detailPlantSpecies?.genus ?: "-"
        if (detailPlantSpecies?.family.isNullOrEmpty() || detailPlantSpecies?.family == "null")
            tv_family_received.text = "-"
        else tv_family_received.text = detailPlantSpecies?.family ?: "-"
        if (detailPlantSpecies?.synonyms.isNullOrBlank()) tv_synonyms_received.text = "-"
        else tv_synonyms_received.text = detailPlantSpecies?.synonyms ?: "-"
    }

    private fun showLoading(state: Boolean) {
        if (state) pb_detail_species.visibility = View.VISIBLE
        else pb_detail_species.visibility = View.GONE
    }
}
