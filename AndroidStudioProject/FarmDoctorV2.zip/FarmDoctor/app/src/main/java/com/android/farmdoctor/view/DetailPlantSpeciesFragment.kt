package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.android.farmdoctor.R
import com.android.farmdoctor.model.DetailPlantSpecies
import com.android.farmdoctor.viewmodel.DetailPlantSpeciesViewModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_plant_species.*
import kotlinx.android.synthetic.main.item_list_plant_species.*

/**
 * A simple [Fragment] subclass.
 */
class DetailPlantSpeciesFragment : Fragment() {

    private lateinit var detailPlantSpeciesViewModel: DetailPlantSpeciesViewModel
    private lateinit var searchQuery: String
    private lateinit var scientificName: String
    private lateinit var commonName: String
    private var itemPosition: Int? = null
    companion object {
        const val EXTRA_SEARCH_QUERY = "extra_search_query"
        const val EXTRA_ITEM_POSITION = "extra_item_position"
        const val EXTRA_SCIENTIFIC_NAME = "extra_scientific_name"
        const val EXTRA_COMMON_NAME = "extra_common_name"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail_plant_species, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        getSelectedPlantSpecies()
        showLoading(true)
        getViewModelLiveData()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) activity?.onBackPressed()
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Plant Species"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedPlantSpecies() {
        if (arguments != null) {
            searchQuery = arguments?.getString(EXTRA_SEARCH_QUERY).toString()
            itemPosition = arguments?.getInt(EXTRA_ITEM_POSITION)
            scientificName = arguments?.getString(EXTRA_SCIENTIFIC_NAME) ?: "-"
            commonName = arguments?.getString(EXTRA_COMMON_NAME) ?: "-"
            tv_scientific_name_received.text = scientificName
            tv_common_name_received.text = "($commonName)"
        }
    }

    private fun getViewModelLiveData() {
        detailPlantSpeciesViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(DetailPlantSpeciesViewModel::class.java)
        detailPlantSpeciesViewModel.apply {
            itemPosition?.let { setDetailPlantSpecies(searchQuery, it, requireContext()) }
            getDetailPlantSpecies().observe(viewLifecycleOwner, Observer {
                if (it != null) {
                    showDetailPlantSpecies(it)
                    showLoading(false)
                }
            })
        }
    }

    private fun showDetailPlantSpecies(detailPlantSpecies: DetailPlantSpecies?) {
        Glide.with(this).load(detailPlantSpecies?.image).into(riv_image_received)
        tv_author_received.text = detailPlantSpecies?.author ?: "-"
        tv_rank_received.text = detailPlantSpecies?.rank ?: "-"
        tv_year_received.text = detailPlantSpecies?.year ?: "-"
        tv_status_received.text = detailPlantSpecies?.status ?: "-"
        tv_genus_received.text = detailPlantSpecies?.genus ?: "-"
        tv_family_received.text = detailPlantSpecies?.family ?: "-"
        tv_synonyms_received.text = detailPlantSpecies?.synonyms ?: "-"
    }

    private fun showLoading(state: Boolean) {
        if (state) pb_detail_species.visibility = View.VISIBLE
        else pb_detail_species.visibility = View.GONE
    }
}
