package com.android.farmdoctor.viewmodel

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.model.PlantSpecies
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class PlantSpeciesViewModel : ViewModel() {

    private val listPlantSpecies = MutableLiveData<ArrayList<PlantSpecies>>()
    private val TAG = PlantSpeciesViewModel::class.java.simpleName

    fun setSearchSpecies(searchQuery: String, context: Context) {
        val listItems = ArrayList<PlantSpecies>()
        val searchUrl = "https://trefle.io/api/v1/species/search?q=$searchQuery"
        val client = AsyncHttpClient(true, 80, 443)
        client.addHeader("Authorization", "token S-ks_Pn6dw6ngztglrmEtkCaWwFXTtsef9KlxPKSDG8")
        client.get(searchUrl, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?
            ) {
                try {
                    val result = responseBody?.let { String(it) }
                    Log.d(TAG, "$result")
                    val responseObject = JSONObject(result.toString())
                    val items = responseObject.getJSONArray("data")
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val dataImage = item.getString("image_url")
                        val dataScientificName = item.getString("scientific_name")
                        val dataCommonName = item.getString("common_name")
                        val dataAuthor = item.getString("author")
                        val dataRank = item.getString("rank")
                        val plantSpecies = PlantSpecies(dataImage,
                            dataScientificName,
                            dataCommonName,
                            dataAuthor,
                            dataRank)
                        listItems.add(plantSpecies)
                    }
                    listPlantSpecies.postValue(listItems)
                } catch (e: Exception) {
                    Log.d(TAG, "${e.message}")
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                val errorMessage = when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d(TAG, errorMessage)
                GlobalScope.launch(Dispatchers.Main) {
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    fun getSearchSpecies(): LiveData<ArrayList<PlantSpecies>> = listPlantSpecies
}