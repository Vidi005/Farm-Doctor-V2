package com.android.farmdoctor.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.android.farmdoctor.R
import com.android.farmdoctor.model.PlantDisease
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.item_list_diseases.view.*
import java.util.*

class PlantDiseasesAdapter(private val listPlantDiseases: ArrayList<PlantDisease>) : RecyclerView.Adapter<PlantDiseasesAdapter.GridViewHolder>(), Filterable {

    private lateinit var onItemClickDetail: OnItemClickCallBack
    private var filterListPlantDiseases: ArrayList<PlantDisease> = listPlantDiseases

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallBack) {
        this.onItemClickDetail = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GridViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_list_diseases, parent, false)
        return GridViewHolder(view)
    }

    override fun getItemCount(): Int = filterListPlantDiseases.size

    override fun onBindViewHolder(holder: GridViewHolder, position: Int) {
        holder.bind(filterListPlantDiseases[position])
    }

    inner class GridViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(plantDisease: PlantDisease) {
            with(itemView) {
                Glide.with(itemView.context)
                    .load(plantDisease.picture)
                    .apply(RequestOptions().override(300, 300))
                    .into(iv_item_picture)
                tv_item_name.text = plantDisease.name
                itemView.setOnClickListener { onItemClickDetail.onItemClicked(plantDisease) }
            }
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val itemSearch = constraint.toString()
                filterListPlantDiseases = if (itemSearch.isEmpty()) {
                    listPlantDiseases
                } else {
                    val itemList = ArrayList<PlantDisease>()
                    for (item in listPlantDiseases) {
                        if (item.name?.toLowerCase(Locale.ROOT)?.contains(itemSearch.toLowerCase(
                                Locale.ROOT))!!) {
                            itemList.add(item)
                        }
                    }
                    itemList
                }
                val filterResults = FilterResults()
                filterResults.values = filterListPlantDiseases
                return filterResults
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filterListPlantDiseases = results?.values as ArrayList<PlantDisease>
                notifyDataSetChanged()
            }
        }
    }

    interface OnItemClickCallBack {
        fun onItemClicked(data: PlantDisease)
    }
}
