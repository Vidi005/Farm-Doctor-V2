package com.android.farmdoctor.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.android.farmdoctor.R
import com.android.farmdoctor.model.PlantSpecies
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.item_list_plant_species.view.*

class PlantSpeciesAdapter(private val plantSpecies: ArrayList<PlantSpecies>) :
    RecyclerView.Adapter<PlantSpeciesAdapter.RecyclerViewHolder>() {

    private lateinit var onItemClickDetail: OnItemClickCallBack

    fun setOnItemClickCallback(onItemClickCallBack: OnItemClickCallBack) {
        this.onItemClickDetail = onItemClickCallBack
    }

    fun setPlantSpeciesData(items: ArrayList<PlantSpecies>) {
        plantSpecies.clear()
        plantSpecies.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_list_plant_species, parent, false)
        return RecyclerViewHolder(view)
    }

    override fun getItemCount(): Int = plantSpecies.size

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) =
        holder.bind(plantSpecies[position])

    inner class RecyclerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        @SuppressLint("SetTextI18n")
        fun bind(plantSpecies: PlantSpecies) {
            with(itemView) {
                Glide.with(itemView.context)
                    .load(plantSpecies.image)
                    .apply(RequestOptions().override(300, 300))
                    .into(riv_item_image)
                tv_item_scientific_name.text = plantSpecies.scientificName ?: "-"
                tv_item_common_name.text = "Common Name: ${plantSpecies.commonName ?: "-"}"
                tv_item_author.text = "Author: ${plantSpecies.author ?: "-"}"
                tv_item_rank.text = "Rank: ${plantSpecies.rank ?: "-"}"
                itemView.setOnClickListener { onItemClickDetail.onItemClicked(plantSpecies) }
            }
        }

    }

    interface OnItemClickCallBack {
        fun onItemClicked(data: PlantSpecies)
    }
}