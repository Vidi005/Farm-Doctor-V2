package com.android.farmdoctor.helper

import android.database.Cursor
import android.provider.BaseColumns._ID
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_ACCURACY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DATE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_IMAGE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_NAME
import com.android.farmdoctor.model.entity.DetectionHistory

object MappingHelper {

    fun mapCursorToArrayList(detectionHistoryCursor: Cursor?): ArrayList<DetectionHistory> {
        val detectionHistoryList = ArrayList<DetectionHistory>()
        detectionHistoryCursor?.apply {
            while (moveToNext()) {
                val id = getInt(getColumnIndexOrThrow(_ID))
                val image = getBlob(getColumnIndexOrThrow(COLUMN_IMAGE))
                val name = getString(getColumnIndexOrThrow(COLUMN_NAME))
                val acc = getString(getColumnIndexOrThrow(COLUMN_ACCURACY))
                val date = getString(getColumnIndexOrThrow(COLUMN_DATE))
                detectionHistoryList.add(DetectionHistory(id, image, name, acc, date))
            }
        }
        return detectionHistoryList
    }
}