package com.android.farmdoctor.viewmodel

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.BuildConfig
import com.android.farmdoctor.model.DetailPlantSpecies
import com.android.farmdoctor.model.Synonym
import com.android.farmdoctor.view.DetailPlantSpeciesFragment.Companion.showErrorAlert
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class DetailPlantSpeciesViewModel : ViewModel() {

    private val detailPlantSpeciesData = MutableLiveData<DetailPlantSpecies>()
    private val TREFLE_API_KEY = BuildConfig.TrefleAPIKEY
    private val TAG = DetailPlantSpeciesViewModel::class.java.simpleName

    private fun parseJson(response: String) {
        val responseObject = JSONObject(response)
        val item = responseObject.getJSONArray("data").getJSONObject(0)
//        val gsonItem = Gson()
//        val dataSynonyms = item.getJSONArray("synonyms")
//        val listSynonyms = ArrayList<Synonym>()
//        for (i in 0 until dataSynonyms.length()) {
//            val dataSynonym = dataSynonyms.getString(i)
//            val synonym = Synonym(i+1, dataSynonym)
//            listSynonyms.add(synonym)
//        }
//        val detailPlantSpecies = gsonItem.fromJson(item.toString(), DetailPlantSpecies::class.java)
        val dataImage = item.getString("image_url")
        val dataAuthor = item.getString("author")
        val dataRank = item.getString("rank")
        val dataYear = item.get("year").toString()
        val dataStatus = item.getString("status")
        val dataGenus = item.getString("genus")
        val dataFamily = item.getString("family")
        val dataSynonyms = item.getJSONArray("synonyms")
        val listSynonyms = ArrayList<Synonym>()
        for (i in 0 until dataSynonyms.length()) {
            val dataSynonym = dataSynonyms.getString(i)
            val synonym = Synonym(i+1, dataSynonym)
            listSynonyms.add(synonym)
        }
        val detailPlantSpecies = DetailPlantSpecies(
            dataImage,
            dataAuthor,
            dataRank,
            dataYear,
            dataStatus,
            dataGenus,
            dataFamily,
            listSynonyms
        )
        detailPlantSpeciesData.postValue(detailPlantSpecies)
    }

    fun setDetailPlantSpecies(scientificName: String, context: Context) {
        val detailUrl = "https://trefle.io/api/v1/plants?filter[scientific_name]=$scientificName"
        val client = AsyncHttpClient(true, 80, 443)
        client.addHeader("Authorization", "token $TREFLE_API_KEY")
        client.get(detailUrl, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?
            ) {
                try {
                    val result = responseBody?.let { String(it) }
                    Log.d(TAG, "$result")
                    result?.let { parseJson(it) }
                } catch (e: Exception) {
                    GlobalScope.launch(Dispatchers.Main) {
                        Toast.makeText(context, "${e.message}", Toast.LENGTH_LONG).show()
                    }
                    Log.d(TAG, "${e.message}")
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                val errorMessage = when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d(TAG, errorMessage)
                GlobalScope.launch(Dispatchers.Main) {
                    //Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                    showErrorAlert(errorMessage, context)
                }
            }
        })
    }

    fun getDetailPlantSpecies(): LiveData<DetailPlantSpecies> = detailPlantSpeciesData
}