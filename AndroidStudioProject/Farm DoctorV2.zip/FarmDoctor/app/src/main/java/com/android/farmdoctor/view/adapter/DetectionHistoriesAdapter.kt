package com.android.farmdoctor.view.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView
import com.android.farmdoctor.R
import com.android.farmdoctor.model.entity.DetectionHistory
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_detection_history.view.*

class DetectionHistoriesAdapter(private val detectionHistories: ArrayList<DetectionHistory>) :
    RecyclerView.Adapter<DetectionHistoriesAdapter.RecyclerViewHolder>() {

    private lateinit var onItemClickDetail: OnItemClickCallBack

    fun setOnItemClickCallback(onItemClickCallBack: OnItemClickCallBack) {
        this.onItemClickDetail = onItemClickCallBack
    }

    fun setDetectionHistoryData(item: ArrayList<DetectionHistory>) {
        detectionHistories.clear()
        detectionHistories.addAll(item)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.item_detection_history, parent, false)
        return RecyclerViewHolder(view)
    }

    override fun getItemCount(): Int = detectionHistories.size

    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) {
        holder.bind(detectionHistories[position])
    }

    inner class RecyclerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        @SuppressLint("SetTextI18n")
        fun bind(detectionHistory: DetectionHistory) {
            with(itemView) {
                tv_history_item_name.text = ": ${detectionHistory.name}"
                tv_history_item_acc.text = ": ${detectionHistory.accuracy}%"
                tv_history_item_date.text = ": ${detectionHistory.date}"
                if (detectionHistory.detectionBased == "Camera") Glide.with(itemView.context)
                    .load(ResourcesCompat.getDrawable(resources, R.drawable.ic_camera, null))
                    .into(iv_detection_based)
                else Glide.with(this.context)
                    .load(ContextCompat.getDrawable(itemView.context, R.drawable.ic_gallery))
                    .into(iv_detection_based)
                itemView.setOnClickListener { onItemClickDetail.onItemClicked(detectionHistory) }
            }
        }

    }

    interface OnItemClickCallBack {
        fun onItemClicked(data: DetectionHistory)
    }
}