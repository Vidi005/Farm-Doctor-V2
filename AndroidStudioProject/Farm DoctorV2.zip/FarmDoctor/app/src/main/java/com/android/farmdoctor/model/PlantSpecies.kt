package com.android.farmdoctor.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class PlantSpecies(
    @field:SerializedName("image_url")
    val image: String?,

    @field:SerializedName("scientific_name")
    val scientificName: String?,

    @field:SerializedName("common_name")
    val commonName: String?,

    @field:SerializedName("author")
    val author: String?,

    @field:SerializedName("rank")
    val rank: String?
) : Parcelable