package com.android.farmdoctor.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.BuildConfig
import com.android.farmdoctor.model.PlantSpecies
import com.android.farmdoctor.view.PlantSpeciesFragment.Companion.showErrorAlert
import com.google.gson.Gson
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject

class PlantSpeciesViewModel : ViewModel() {

    private val listPlantSpecies = MutableLiveData<ArrayList<PlantSpecies>>()
    private val TREFLE_API_KEY = BuildConfig.TrefleAPIKEY
    private val TAG = PlantSpeciesViewModel::class.java.simpleName

    fun setSearchSpecies(searchQuery: String, context: Context) {
        val listItems = ArrayList<PlantSpecies>()
        val searchUrl = "https://trefle.io/api/v1/species/search?q=$searchQuery"
        val client = AsyncHttpClient(true, 80, 443)
        client.addHeader("Authorization", "token $TREFLE_API_KEY")
        client.get(searchUrl, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?
            ) {
                try {
                    val result = responseBody?.let { String(it) }
                    Log.d(TAG, "$result")
                    val responseObject = JSONObject(result.toString())
                    val items = responseObject.getJSONArray("data")
                    for (i in 0 until items.length()) {
                        val gsonItem = Gson()
                        val plantSpecies = gsonItem
                            .fromJson(items.getJSONObject(i).toString(), PlantSpecies::class.java)
                        listItems.add(plantSpecies)
                    }
                    listPlantSpecies.postValue(listItems)
                } catch (e: Exception) {
                    Log.d(TAG, "${e.message}")
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                val errorMessage = when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d(TAG, errorMessage)
                GlobalScope.launch(Dispatchers.Main) {
                    //Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                    showErrorAlert(errorMessage, context)
                }
            }
        })
    }

    fun getSearchSpecies(): LiveData<ArrayList<PlantSpecies>> = listPlantSpecies
}