package com.android.farmdoctor.database

import android.provider.BaseColumns

object DatabaseContract {

    internal class DetectionResultColumns : BaseColumns {

        companion object {
            const val TABLE_NAME = "detection_history"
            const val COLUMN_IMAGE = "image"
            const val COLUMN_NAME = "name"
            const val COLUMN_ACCURACY = "acc"
            const val COLUMN_DATE = "date"
            const val COLUMN_LATENCY = "latency"
            const val COLUMN_LATITUDE = "latitude"
            const val COLUMN_LONGITUDE = "longitude"
            const val COLUMN_DETECTION_BASED = "detection_based"
        }
    }
}