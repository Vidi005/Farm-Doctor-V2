package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.android.farmdoctor.R
import com.android.farmdoctor.database.DetectionHistoryHelper
import com.android.farmdoctor.model.LocationAddress
import com.android.farmdoctor.model.entity.DetectionHistory
import com.android.farmdoctor.viewmodel.LocationAddressViewModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_detection_history.*

/**
 * A simple [Fragment] subclass.
 */
class DetailDetectionHistoryFragment : Fragment() {

    companion object {
        const val EXTRA_DETECTION_HISTORY = "extra_detection_history"
    }
    private lateinit var detectionHistoryHelper: DetectionHistoryHelper
    private lateinit var locationAddressViewModel: LocationAddressViewModel
    private lateinit var dataLatitude: String
    private lateinit var dataLongitude: String
    private var detectionHistory: DetectionHistory? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_detail_detection_history, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        getSelectedDetectionHistory()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_delete, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        showAlertDialog(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Detection History"
        }
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) requireActivity().onBackPressed()
    }

    @SuppressLint("SetTextI18n")
    private fun getViewModelLiveData() {
        locationAddressViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(LocationAddressViewModel::class.java)
        locationAddressViewModel.apply {
            setLocationAddress(requireContext(), dataLatitude.toDouble(), dataLongitude.toDouble())
            getLocationAddress().observe(viewLifecycleOwner, Observer {
                if (it != null) showDetailLocationAddress(it)
                else tv_history_location_received.text = "$dataLatitude, $dataLongitude"
            })
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showDetailLocationAddress(locationAddress: LocationAddress?) {
        val dataAddress = locationAddress?.address
        tv_history_location_received.text = "$dataAddress"
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedDetectionHistory() {
        if (arguments != null) {
            detectionHistory = arguments?.get(EXTRA_DETECTION_HISTORY) as DetectionHistory
            val dataImage = detectionHistory?.image
            val dataName = detectionHistory?.name
            val dataAcc = detectionHistory?.accuracy
            val dataDate = detectionHistory?.date
            val dataLatency = detectionHistory?.latency
            dataLatitude = detectionHistory?.latitude.toString()
            dataLongitude = detectionHistory?.longitude.toString()
            Glide.with(this).load(dataImage).into(iv_history_image_received)
            tv_history_name_received.text = "Name: $dataName"
            tv_history_acc_received.text = "Probability: $dataAcc%"
            tv_history_date_received.text = dataDate
            tv_history_latency_received.text = "$dataLatency ms"
            if (dataLatitude == "Location disabled" && dataLongitude == "Location disabled")
                group_location.visibility = View.GONE
            else if (dataLatitude == "null" || dataLongitude == "null")
                tv_history_location_received.text = "Location Not Available"
            else {
                tv_history_location_received.text = "$dataLatitude, $dataLongitude"
                getViewModelLiveData()
            }
        }
    }

    private fun showAlertDialog(showAlertDialog: Int) {
        if (showAlertDialog == R.id.app_bar_delete) {
            val dialogTitle = "Delete History"
            val dialogMessage = "Are you sure want to delete this history?"
            val alertDialogBuilder = AlertDialog.Builder(requireContext())
            alertDialogBuilder.setTitle(dialogTitle)
            alertDialogBuilder
                .setMessage(dialogMessage)
                .setPositiveButton("Yes") { _, _ -> deleteDetectionHistory() }
                .setNegativeButton("No") { dialog, _ -> dialog.cancel() }
            val alertDialog = alertDialogBuilder.create()
            alertDialog.show()
        }
    }

    private fun deleteDetectionHistory() {
        detectionHistoryHelper = DetectionHistoryHelper.getInstance(requireContext())
        detectionHistoryHelper.open()
        val result = detectionHistoryHelper.deleteById(detectionHistory?.id.toString()).toLong()
        if (result > 0) {
            activity?.onBackPressed()
            Toast.makeText(activity, "History successfully deleted", Toast.LENGTH_SHORT).show()
        } else Toast.makeText(activity, "Failed to delete the history!", Toast.LENGTH_LONG).show()
    }
}
