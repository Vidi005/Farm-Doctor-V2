package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.farmdoctor.R
import com.android.farmdoctor.model.DetailPlantSpecies
import com.android.farmdoctor.model.Synonym
import com.android.farmdoctor.view.adapter.PlantSynonymsAdapter
import com.android.farmdoctor.viewmodel.DetailPlantSpeciesViewModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_detail_plant_species.*
import kotlinx.android.synthetic.main.layout_synonym.*

/**
 * A simple [Fragment] subclass.
 */
class DetailPlantSpeciesFragment : Fragment() {

    private lateinit var detailPlantSpeciesViewModel: DetailPlantSpeciesViewModel
    private lateinit var plantSynonymsAdapter: PlantSynonymsAdapter
    private lateinit var scientificName: String
    private lateinit var commonName: String
    companion object {
        const val EXTRA_SCIENTIFIC_NAME = "extra_scientific_name"
        const val EXTRA_COMMON_NAME = "extra_common_name"
        fun showErrorAlert(showErrorAlert: String?, context: Context) {
            val dialogTitle = "Connection Error"
            val alertDialogBuilder = AlertDialog.Builder(context)
            alertDialogBuilder
                .setTitle(dialogTitle)
                .setMessage(showErrorAlert)
                .setPositiveButton("OK") { dialog, _ -> dialog.cancel() }
            val errorAlert = alertDialogBuilder.create()
            if (errorAlert.isShowing) errorAlert.cancel()
            else errorAlert.show()
        }
    }
    private val list = ArrayList<Synonym>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_detail_plant_species, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        getSelectedPlantSpecies()
        showLoading(true)
        getViewModelLiveData()
        showRecyclerView()
    }

    private fun showRecyclerView() {
        rv_list_synonym.layoutManager = LinearLayoutManager(activity)
        plantSynonymsAdapter = PlantSynonymsAdapter(list)
        rv_list_synonym.adapter = plantSynonymsAdapter
        plantSynonymsAdapter.notifyDataSetChanged()
        rv_list_synonym.setHasFixedSize(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) activity?.onBackPressed()
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Plant Species"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedPlantSpecies() {
        if (arguments != null) {
            scientificName = arguments?.getString(EXTRA_SCIENTIFIC_NAME) ?: "-"
            commonName = arguments?.getString(EXTRA_COMMON_NAME) ?: "-"
            tv_scientific_name_received.text = scientificName
            if (commonName.isEmpty() || commonName == "null") tv_common_name_received.text = ""
            else tv_common_name_received.text = "($commonName)"
        }
    }

    private fun getViewModelLiveData() {
        detailPlantSpeciesViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(DetailPlantSpeciesViewModel::class.java)
        detailPlantSpeciesViewModel.apply {
            setDetailPlantSpecies(scientificName, requireContext())
            getDetailPlantSpecies().observe(viewLifecycleOwner, Observer {
                if (it != null) {
                    showDetailPlantSpecies(it)
                    if (it.synonyms != null) showSynonyms(it.synonyms)
                    showLoading(false)
                }
            })
        }
    }

    private fun showDetailPlantSpecies(detailPlantSpecies: DetailPlantSpecies?) {
        if (detailPlantSpecies?.image.isNullOrBlank() || detailPlantSpecies?.image == "null")
            Glide.with(this).load(R.drawable.ic_no_image).into(riv_image_received)
        else Glide.with(this).load(detailPlantSpecies?.image).into(riv_image_received)
        if (detailPlantSpecies?.author.isNullOrEmpty() || detailPlantSpecies?.author == "null")
            tv_author_received.text = "-"
        else tv_author_received.text = detailPlantSpecies?.author ?: "-"
        if (detailPlantSpecies?.rank.isNullOrEmpty() || detailPlantSpecies?.rank == "null")
            tv_rank_received.text = "-"
        else tv_rank_received.text = detailPlantSpecies?.rank ?: "-"
        if (detailPlantSpecies?.year.isNullOrEmpty() || detailPlantSpecies?.year == "null")
            tv_year_received.text = "-"
        else tv_year_received.text = detailPlantSpecies?.year ?: "-"
        if (detailPlantSpecies?.status.isNullOrEmpty() || detailPlantSpecies?.status == "null")
            tv_status_received.text = "-"
        else tv_status_received.text = detailPlantSpecies?.status ?: "-"
        if (detailPlantSpecies?.genus.isNullOrEmpty() || detailPlantSpecies?.genus == "null")
            tv_genus_received.text = "-"
        else tv_genus_received.text = detailPlantSpecies?.genus ?: "-"
        if (detailPlantSpecies?.family.isNullOrEmpty() || detailPlantSpecies?.family == "null")
            tv_family_received.text = "-"
        else tv_family_received.text = detailPlantSpecies?.family ?: "-"
    }

    @SuppressLint("SetTextI18n")
    private fun showSynonyms(synonymItems: ArrayList<Synonym>?) {
        synonymItems?.let { plantSynonymsAdapter.setPlantSynonymData(it) }
        if (synonymItems?.size as Int > 0) {
            tv_synonym_bar.text = "Synonyms: ${synonymItems.size}"
            showEmptySynonym(false)
        } else {
            tv_synonym_bar.text = "Synonyms: 0"
            showEmptySynonym(true)
        }
    }

    private fun showEmptySynonym(state: Boolean) {
        if (state) {
            iv_no_synonym.visibility = View.VISIBLE
            tv_no_synonym.visibility = View.VISIBLE
        } else {
            iv_no_synonym.visibility = View.GONE
            tv_no_synonym.visibility = View.GONE
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) pb_detail_species.visibility = View.VISIBLE
        else pb_detail_species.visibility = View.GONE
    }
}
