package com.android.farmdoctor.manager

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import android.util.Log
import com.android.farmdoctor.view.CameraFragment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LocationManager {

    companion object {
        var locationManager: LocationManager? = null
        var latitudeData: String? = null
        var longitudeData: String? = null
    }
    private val TAG = com.android.farmdoctor.manager.LocationManager::class.java.simpleName

    @SuppressLint("MissingPermission")
    fun getLastLocation(context: Context) {
        locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        GlobalScope.launch(Dispatchers.Default) {
            while (true) {
                val location =
                    locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (location != null) {
                    latitudeData = location.latitude.toString()
                    longitudeData = location.longitude.toString()
                } else {
                    latitudeData = "null"
                    longitudeData = "null"
                    Log.d(TAG, "Location not found!")
                }
                delay(10000L)
            }
        }
    }
}