package com.android.farmdoctor.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns._ID
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_ACCURACY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DATE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DETECTION_BASED
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_IMAGE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LATENCY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LATITUDE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LONGITUDE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_NAME
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.TABLE_NAME

internal class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context,
        DATABASE_NAME, null,
        DATABASE_VERSION
    ) {

    companion object {
        private const val DATABASE_NAME = "db_detection_history.db"
        private const val DATABASE_VERSION = 1
        private const val SQL_CREATE_TABLE_DETECTION_HISTORY = "CREATE TABLE $TABLE_NAME" +
                " ($_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " $COLUMN_IMAGE BLOB NOT NULL," +
                " $COLUMN_NAME TEXT NOT NULL," +
                " $COLUMN_ACCURACY TEXT NOT NULL," +
                " $COLUMN_DATE TEXT NOT NULL," +
                " $COLUMN_LATENCY TEXT NOT NULL," +
                " $COLUMN_LATITUDE TEXT NOT NULL," +
                " $COLUMN_LONGITUDE TEXT NOT NULL," +
                " $COLUMN_DETECTION_BASED TEXT NOT NULL)"
    }
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(SQL_CREATE_TABLE_DETECTION_HISTORY)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }
}