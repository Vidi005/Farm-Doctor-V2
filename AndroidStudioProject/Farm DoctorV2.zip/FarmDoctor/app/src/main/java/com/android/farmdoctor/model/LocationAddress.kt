package com.android.farmdoctor.model

data class LocationAddress(val address: String?)