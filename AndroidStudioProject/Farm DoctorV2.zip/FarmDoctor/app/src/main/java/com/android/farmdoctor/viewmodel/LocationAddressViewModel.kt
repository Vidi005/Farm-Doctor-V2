package com.android.farmdoctor.viewmodel

import android.content.Context
import android.location.Geocoder
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.farmdoctor.model.LocationAddress
import kotlinx.coroutines.*
import java.util.*

class LocationAddressViewModel: ViewModel() {

    private val locationAddressData = MutableLiveData<LocationAddress>()
    private val TAG = LocationAddressViewModel::class.java.simpleName

    fun setLocationAddress(context: Context, latitude: Double, longitude: Double) {
        val geocode = Geocoder(context, Locale.getDefault())
        GlobalScope.launch(Dispatchers.IO) {
            try {
                for (i in 0..2) {
                    val addresses = geocode.getFromLocation(latitude, longitude, 1)
                    delay(1000L)
                    if (addresses != null && addresses.size > 0) {
                        val address = addresses[0].getAddressLine(0)
                        val locationAddress = LocationAddress(address)
                        Log.d(TAG, address)
                        locationAddressData.postValue(locationAddress)
                        break
                    } else withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Geocoding Error!", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "${e.message}", Toast.LENGTH_LONG).show()
                }
                Log.d(TAG, "${e.message}")
            }
        }
    }

    fun getLocationAddress(): LiveData<LocationAddress> = locationAddressData
}