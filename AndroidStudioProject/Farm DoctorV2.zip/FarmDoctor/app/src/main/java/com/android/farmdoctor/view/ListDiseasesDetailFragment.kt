package com.android.farmdoctor.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.android.farmdoctor.R
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_list_diseases_detail.*

/**
 * A simple [Fragment] subclass.
 */
class ListDiseasesDetailFragment : Fragment() {

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_PICTURE = "extra_picture"
        const val EXTRA_DETAIL = "extra_detail"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_list_diseases_detail, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        getSelectedPlantDisease()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Plant Disease"
        }
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) requireActivity().onBackPressed()
    }

    private fun getSelectedPlantDisease() {
        if (arguments != null) {
            val image = arguments?.getInt(EXTRA_PICTURE, 0)
            val name = arguments?.getString(EXTRA_NAME).toString()
            val detail = arguments?.getInt(EXTRA_DETAIL, 0)
            Glide.with(this).load(image).into(riv_picture_received)
            tv_name_received.text = name
            if (detail != null) {
                vs_detail_received.layoutResource = detail
                vs_detail_received.inflate()
            }
        }
    }
}
