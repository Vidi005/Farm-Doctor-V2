package com.android.farmdoctor.helper

import android.database.Cursor
import android.provider.BaseColumns._ID
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_ACCURACY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DATE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_DETECTION_BASED
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_IMAGE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LATENCY
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LATITUDE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_LONGITUDE
import com.android.farmdoctor.database.DatabaseContract.DetectionResultColumns.Companion.COLUMN_NAME
import com.android.farmdoctor.model.entity.DetectionHistory

object MappingHelper {

    fun mapCursorToArrayList(detectionHistoryCursor: Cursor?): ArrayList<DetectionHistory> {
        val detectionHistoryList = ArrayList<DetectionHistory>()
        detectionHistoryCursor?.apply {
            while (moveToNext()) {
                val id = getInt(getColumnIndexOrThrow(_ID))
                val image = getBlob(getColumnIndexOrThrow(COLUMN_IMAGE))
                val name = getString(getColumnIndexOrThrow(COLUMN_NAME))
                val acc = getString(getColumnIndexOrThrow(COLUMN_ACCURACY))
                val date = getString(getColumnIndexOrThrow(COLUMN_DATE))
                val latency = getString(getColumnIndexOrThrow(COLUMN_LATENCY))
                val latitude = getString(getColumnIndexOrThrow(COLUMN_LATITUDE))
                val longitude = getString(getColumnIndexOrThrow(COLUMN_LONGITUDE))
                val detectionBased = getString(getColumnIndexOrThrow(COLUMN_DETECTION_BASED))
                detectionHistoryList.add(DetectionHistory(id, image, name, acc, date, latency, latitude, longitude, detectionBased))
            }
        }
        return detectionHistoryList
    }
}