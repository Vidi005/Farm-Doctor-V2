package com.android.farmdoctor.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.farmdoctor.R
import com.android.farmdoctor.database.DetectionHistoryHelper
import com.android.farmdoctor.model.entity.DetectionHistory
import com.android.farmdoctor.view.DetailDetectionHistoryFragment.Companion.EXTRA_DETECTION_HISTORY
import com.android.farmdoctor.view.adapter.DetectionHistoriesAdapter
import com.android.farmdoctor.viewmodel.DetectionHistoriesViewModel
import kotlinx.android.synthetic.main.fragment_detection_histories.*

/**
 * A simple [Fragment] subclass.
 */
class DetectionHistoriesFragment : Fragment() {

    private lateinit var detectionHistoriesAdapter: DetectionHistoriesAdapter
    private lateinit var detectionHistoriesViewModel: DetectionHistoriesViewModel
    private lateinit var detectionHistoryHelper: DetectionHistoryHelper
    private val list = ArrayList<DetectionHistory>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detection_histories, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setActionBar()
        setHasOptionsMenu(true)
        showRecyclerView()
        getViewModelLiveData()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_delete_all, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        onNavigateUp(item.itemId)
        showAlertDialog(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setActionBar() {
        (activity as AppCompatActivity?)?.supportActionBar?.apply {
            setHomeButtonEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            title = "Detection Histories"
        }
    }

    private fun onNavigateUp(itemId: Int) {
        if (itemId == android.R.id.home) requireActivity().onBackPressed()
    }

    private fun showAlertDialog(showAlertDialog: Int) {
        if (showAlertDialog == R.id.app_bar_delete_all) {
            val dialogTitle = "Delete All Histories"
            val dialogMessage = "Are you sure want to delete all histories?"
            val alertDialogBuilder = AlertDialog.Builder(requireContext())
            alertDialogBuilder.setTitle(dialogTitle)
            alertDialogBuilder
                .setMessage(dialogMessage)
                .setPositiveButton("Yes") { _, _ -> deleteAllHistories() }
                .setNegativeButton("No") { dialog, _ -> dialog.cancel() }
            val alertDialog = alertDialogBuilder.create()
            alertDialog.show()
        }
    }

    private fun showRecyclerView() {
        rv_detection_history.setHasFixedSize(true)
        rv_detection_history.layoutManager = LinearLayoutManager(activity)
        detectionHistoriesAdapter = DetectionHistoriesAdapter(list)
        rv_detection_history.adapter = detectionHistoriesAdapter
        detectionHistoriesAdapter.apply {
            notifyDataSetChanged()
            setOnItemClickCallback(object : DetectionHistoriesAdapter.OnItemClickCallBack {
                override fun onItemClicked(data: DetectionHistory) {
                    setSelectedDetectionHistory(data)
                }
            })
        }
    }

    private fun setSelectedDetectionHistory(data: DetectionHistory) {
        val mBundle = Bundle().apply {
            putParcelable(EXTRA_DETECTION_HISTORY, data)
        }
        NavHostFragment.findNavController(this).navigate(R.id.action_detectionHistoriesFragment_to_detailDetectionHistoryFragment, mBundle)
    }

    private fun getViewModelLiveData() {
        detectionHistoriesViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())
            .get(DetectionHistoriesViewModel::class.java).apply {
                tv_saved_histories.text = "Loading Data..."
                showLoadingDetectionHistories(true)
                setDetectionHistory(requireContext())
                getDetectionHistory().observe(viewLifecycleOwner, Observer {
                    if (it != null) {
                        showDetectionHistoryItems(it)
                        showLoadingDetectionHistories(false)
                    }
                })
            }
    }

    @SuppressLint("SetTextI18n")
    private fun showDetectionHistoryItems(detectionHistoryItems: ArrayList<DetectionHistory>?) {
        detectionHistoryItems?.let { detectionHistoriesAdapter.setDetectionHistoryData(it) }
        if (detectionHistoryItems?.size as Int >= 1) tv_saved_histories.text =
            "Saved Detection Results: ${detectionHistoryItems.size}"
        else if (detectionHistoryItems.size == 0) tv_saved_histories.text = "No Detection History was Saved"
    }

    private fun deleteAllHistories() {
        detectionHistoryHelper = DetectionHistoryHelper.getInstance(requireContext())
        detectionHistoryHelper.open()
        val result = detectionHistoryHelper.deleteAll()
        when {
            result > 0 -> {
                Toast.makeText(activity, "All histories successfully deleted", Toast.LENGTH_SHORT).show()
                list.clear()
                showRecyclerView()
                tv_saved_histories.text = "No Detection History was Saved"
            }
            result == 0 -> Toast.makeText(activity, "All histories have been deleted", Toast.LENGTH_SHORT).show()
            else -> Toast.makeText(activity, "Failed to delete all histories!", Toast.LENGTH_LONG).show()
        }
    }

    private fun showLoadingDetectionHistories(state: Boolean) {
        if (state) pb_history.visibility = View.VISIBLE
        else pb_history.visibility = View.GONE
    }
}
