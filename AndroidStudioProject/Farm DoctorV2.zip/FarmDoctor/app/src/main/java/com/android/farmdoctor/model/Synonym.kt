package com.android.farmdoctor.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Synonym(val number: Int, val synonym: String?) : Parcelable